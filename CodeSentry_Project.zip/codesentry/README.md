# CodeSentry

A local-first source-code comment and sensitive-data audit tool. It provides an HTML analyst dashboard, a Python/Flask scanning API, background scan jobs, and multi-sheet Excel reports.

## Features

- Scans Java, JSP, HTML, JavaScript, TypeScript, React (JSX/TSX), Angular templates, CSS/SCSS/Less, Python, and Ruby.
- Extracts comments using Pygments lexers (with a conservative fallback).
- Detects likely credentials, tokens, private keys, personal data, and sensitive identifiers **inside comments**.
- Supports large repositories through background jobs, per-file processing, excluded directories, and configurable file-size limits.
- Reports findings by file and inferred package/module, with line numbers, severity, confidence, and masked evidence.
- Exports an Excel workbook with `Summary`, `Findings`, `File Summary`, and `Package Summary` sheets.
- Local-only by default; no source code is uploaded to a remote service.

## Requirements

- Python 3.10+
- Windows, macOS, or Linux

## Run

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

Open http://127.0.0.1:5000

## Use

1. Enter an absolute project directory path in the dashboard.
2. Optionally adjust excluded folders and maximum file size.
3. Start the scan and watch progress.
4. Review findings, filter by severity, and export the Excel report.

## API

- `GET /api/health`
- `POST /api/scan` JSON: `{"project_path":"/absolute/path","max_file_mb":10,"exclude_dirs":["node_modules",".git"]}`
- `GET /api/status/<job_id>`
- `GET /api/report/<job_id>` downloads the generated XLSX when complete.

## Security and operational notes

- Bind to `127.0.0.1` only. Do not expose this service to an untrusted network: users who can access the dashboard may ask the server to scan paths readable by its OS account.
- Run with the least-privileged OS account that can read the target repository.
- The tool reads files only; it does not modify source files or execute project code.
- Evidence is masked in the UI and workbook. The scanner does not store full matched credential values in the report.
- Regex-based findings are triage signals, not proof of exposure. Review context and validate findings manually.
- The default file-size cap is 10 MB per file. Increase it only when needed.
- Generated reports are stored in a temporary `reports/` directory under the project root. Remove reports when no longer needed.

## Detection scope

This tool is intentionally focused on **comments**. It is not a full SAST engine, secret scanner for executable code, dependency vulnerability scanner, or data-flow analyzer. Pygments tokenization improves comment extraction, but language grammars and template mixtures can still produce edge cases. Add language-specific parsers and organization-specific patterns for production assurance.

## Project layout

```text
codesentry/
├── app/
│   ├── __init__.py
│   ├── scanner.py
│   ├── reporting.py
│   ├── templates/index.html
│   └── static/app.css
├── tests/test_scanner.py
├── requirements.txt
└── run.py
```
