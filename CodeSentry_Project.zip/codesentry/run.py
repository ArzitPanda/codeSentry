from app import create_app

app = create_app()

if __name__ == "__main__":
    # Local-only binding is deliberate. Do not change to 0.0.0.0 without
    # adding authentication, authorization, CSRF protection, and deployment hardening.
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
