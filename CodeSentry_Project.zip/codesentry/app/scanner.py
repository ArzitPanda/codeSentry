from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
import re
import os

from pygments import lex
from pygments.lexers import get_lexer_for_filename, HtmlLexer
from pygments.token import Comment, Token

SUPPORTED = {
    ".java", ".jsp", ".html", ".htm", ".js", ".mjs", ".cjs", ".jsx",
    ".ts", ".tsx", ".css", ".scss", ".less", ".py", ".rb"
}

RULES = [
    ("PRIVATE_KEY", "Private key material", "Critical", 0.99,
     re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----", re.I)),
    ("AWS_ACCESS_KEY", "Cloud access key", "Critical", 0.98,
     re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("JWT_TOKEN", "JWT-like token", "High", 0.94,
     re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b")),
    ("GENERIC_SECRET", "Password / secret assignment", "High", 0.90,
     re.compile(r"\b(?:password|passwd|pwd|secret|client_secret)\s*[:=]\s*['\"]?([^\s,'\";]{4,})", re.I)),
    ("API_TOKEN", "API key / access token assignment", "High", 0.88,
     re.compile(r"\b(?:api[_-]?key|access[_-]?token|auth[_-]?token|bearer[_-]?token)\s*[:=]\s*['\"]?([A-Za-z0-9._~+/=-]{8,})", re.I)),
    ("GENERIC_KEY", "Key-like assignment", "High", 0.82,
     re.compile(r"\b(?:private[_-]?key|encryption[_-]?key|signing[_-]?key)\s*[:=]\s*['\"]?([A-Za-z0-9._~+/=-]{8,})", re.I)),
    ("EMAIL", "Email address (PII)", "High", 0.96,
     re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)),
    ("PHONE", "Phone number (possible PII)", "Medium", 0.78,
     re.compile(r"(?<!\w)(?:\+?\d{1,3}[- .]?)?(?:\d[- .]?){9,12}\d(?!\w)")),
    ("AADHAAR", "Aadhaar-like identifier (India)", "High", 0.91,
     re.compile(r"\b[2-9]\d{3}\s?\d{4}\s?\d{4}\b")),
    ("PAN", "PAN-like identifier (India)", "High", 0.90,
     re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b", re.I)),
    ("SENSITIVE_ID", "Sensitive identifier reference", "High", 0.80,
     re.compile(r"\b(?:customer|employee|account|national|passport|patient)[_-]?(?:id|number|no)\s*[:=]\s*['\"]?[\w-]{4,}", re.I)),
]

def _fallback_comments(text, suffix):
    """Conservative fallback for common comment syntaxes."""
    patterns = {
        ".py": r"(?m)#.*$", ".rb": r"(?m)#.*$",
        ".html": r"(?s)<!--.*?-->", ".htm": r"(?s)<!--.*?-->",
        ".jsp": r"(?s)<!--.*?-->|<%--.*?--%>",
        ".java": r"(?s)/\*.*?\*/|(?m)//.*$",
        ".js": r"(?s)/\*.*?\*/|(?m)//.*$", ".jsx": r"(?s)/\*.*?\*/|(?m)//.*$",
        ".ts": r"(?s)/\*.*?\*/|(?m)//.*$", ".tsx": r"(?s)/\*.*?\*/|(?m)//.*$",
        ".css": r"(?s)/\*.*?\*/", ".scss": r"(?s)/\*.*?\*/|(?m)//.*$",
        ".less": r"(?s)/\*.*?\*/|(?m)//.*$",
    }
    return [(m.start(), m.group(0)) for m in re.finditer(patterns.get(suffix, r"$^"), text)]

def extract_comments(text, path):
    """Return (line_number, comment_text) pairs. Prefer lexer tokenization."""
    suffix = Path(path).suffix.lower()
    try:
        try:
            lexer = get_lexer_for_filename(str(path), stripnl=False, ensurenl=True)
        except Exception:
            lexer = HtmlLexer(stripnl=False, ensurenl=True) if suffix in {".jsp", ".html", ".htm"} else None
        if lexer is not None:
            comments = []
            line = 1
            for token, value in lex(text, lexer):
                if token in Comment or token in Token.Comment:
                    comments.append((line, value))
                line += value.count("\n")
            if comments or not text.strip():
                return comments
    except Exception:
        pass

    comments = []
    for offset, value in _fallback_comments(text, suffix):
        comments.append((text.count("\n", 0, offset) + 1, value))
    return comments

def _mask(value):
    value = str(value)
    if len(value) <= 4:
        return "*" * len(value)
    return value[:2] + "*" * min(12, len(value) - 4) + value[-2:]

def _package_for(path, root):
    rel = Path(path).relative_to(root)
    parts = rel.parts[:-1]
    return ".".join(parts) if parts else "(root)"

def _findings_for_comment(comment, file_path, rel_path, package, line_number):
    findings = []
    normalized_preview = re.sub(r"\s+", " ", comment).strip()
    for rule_id, title, severity, confidence, pattern in RULES:
        for match in pattern.finditer(comment):
            raw = match.group(0)
            # Avoid weak phone matches unless there are at least 10 digits.
            if rule_id == "PHONE" and sum(ch.isdigit() for ch in raw) < 10:
                continue
            # Redact matched values from the preview too; never leak the original
            # credential/PII into the UI or exported workbook.
            normalized_preview = normalized_preview.replace(raw, _mask(raw))
            findings.append({
                "rule_id": rule_id,
                "title": title,
                "severity": severity,
                "confidence": confidence,
                "file": rel_path,
                "absolute_file": str(file_path),
                "package": package,
                "line": line_number,
                "evidence": _mask(raw),
                "comment_preview": normalized_preview[:240],
            })
    # Ensure all findings for the same comment receive the fully redacted preview.
    for finding in findings:
        finding["comment_preview"] = normalized_preview[:240]
    return findings

def scan_project(project_path, exclude_dirs=None, max_file_bytes=10 * 1024 * 1024, progress_callback=None):
    root = Path(project_path).resolve()
    if not root.is_dir():
        raise ValueError("Project path is not a directory.")

    excluded = set(exclude_dirs or [])
    candidates = []
    for current, dirs, filenames in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in excluded and not d.startswith(".cache"))
        for filename in filenames:
            p = Path(current) / filename
            if p.suffix.lower() in SUPPORTED:
                try:
                    if p.stat().st_size <= max_file_bytes:
                        candidates.append(p)
                except OSError:
                    continue

    findings, file_rows = [], []
    total = len(candidates)
    scanned = 0
    skipped_binary = 0
    for path in candidates:
        rel = str(path.relative_to(root)).replace("\\", "/")
        package = _package_for(path, root)
        file_findings = 0
        try:
            text = path.read_text(encoding="utf-8-sig", errors="replace")
            if "\x00" in text[:4096]:
                skipped_binary += 1
                continue
            for line_no, comment in extract_comments(text, path):
                hits = _findings_for_comment(comment, path, rel, package, line_no)
                findings.extend(hits)
                file_findings += len(hits)
            file_rows.append({
                "file": rel, "package": package, "extension": path.suffix.lower(),
                "size_bytes": path.stat().st_size, "finding_count": file_findings
            })
        except (OSError, UnicodeError):
            pass
        scanned += 1
        if progress_callback and (scanned % 10 == 0 or scanned == total):
            progress_callback({
                "percent": int(scanned * 100 / total) if total else 100,
                "scanned_files": scanned, "total_files": total,
                "current_file": rel
            })

    severity_counts = Counter(f["severity"] for f in findings)
    rule_counts = Counter(f["rule_id"] for f in findings)
    package_counts = defaultdict(int)
    for f in findings:
        package_counts[f["package"]] += 1
    package_rows = [{"package": k, "finding_count": v} for k, v in sorted(package_counts.items(), key=lambda x: (-x[1], x[0]))]
    summary = {
        "project": str(root), "scan_time": datetime.now(timezone.utc).isoformat(),
        "files_discovered": total, "files_scanned": scanned,
        "comments_with_findings": len(findings), "total_findings": len(findings),
        "critical": severity_counts["Critical"], "high": severity_counts["High"],
        "medium": severity_counts["Medium"], "low": severity_counts["Low"],
        "skipped_binary": skipped_binary, "rule_counts": dict(rule_counts)
    }
    return {"summary": summary, "findings": findings, "file_summary": file_rows, "package_summary": package_rows}
