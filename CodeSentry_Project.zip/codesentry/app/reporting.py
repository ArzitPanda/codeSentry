from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from pathlib import Path

def _style(ws):
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="172554")
        cell.alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 26
    for col in ws.columns:
        values = [len(str(c.value or "")) for c in list(col)[:250]]
        width = min(max(max(values, default=10) + 2, 12), 55)
        ws.column_dimensions[get_column_letter(col[0].column)].width = width

def build_workbook(result, output_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    summary = result["summary"]
    ws.append(["Metric", "Value"])
    for key, value in summary.items():
        if isinstance(value, dict):
            value = ", ".join(f"{k}: {v}" for k, v in value.items())
        ws.append([key.replace("_", " ").title(), value])
    _style(ws)

    ws = wb.create_sheet("Findings")
    headers = ["Severity", "Confidence", "Rule ID", "Finding", "File", "Package", "Line", "Masked Evidence", "Comment Preview"]
    ws.append(headers)
    for f in result["findings"]:
        ws.append([f["severity"], f["confidence"], f["rule_id"], f["title"], f["file"],
                   f["package"], f["line"], f["evidence"], f["comment_preview"]])
    _style(ws)

    ws = wb.create_sheet("File Summary")
    ws.append(["File", "Package", "Extension", "Size (bytes)", "Finding Count"])
    for row in result["file_summary"]:
        ws.append([row["file"], row["package"], row["extension"], row["size_bytes"], row["finding_count"]])
    _style(ws)

    ws = wb.create_sheet("Package Summary")
    ws.append(["Package / Directory", "Finding Count"])
    for row in result["package_summary"]:
        ws.append([row["package"], row["finding_count"]])
    _style(ws)

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)
    return output_path
