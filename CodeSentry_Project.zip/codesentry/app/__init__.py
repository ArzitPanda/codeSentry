from flask import Flask, jsonify, render_template, request, send_file, abort
from pathlib import Path
from threading import Thread, Lock
from uuid import uuid4
from datetime import datetime, timezone
import os

from .scanner import scan_project
from .reporting import build_workbook

JOBS = {}
JOBS_LOCK = Lock()

DEFAULT_EXCLUDES = {
    ".git", ".svn", ".hg", "node_modules", "bower_components", "vendor",
    "dist", "build", "coverage", ".next", ".nuxt", ".angular",
    ".venv", "venv", "__pycache__", ".pytest_cache", "target", "bin", "obj"
}

def create_app():
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok", "service": "CodeSentry"})

    def run_job(job_id, project_path, options):
        with JOBS_LOCK:
            JOBS[job_id]["status"] = "running"
            JOBS[job_id]["started_at"] = datetime.now(timezone.utc).isoformat()
        try:
            result = scan_project(
                project_path=project_path,
                exclude_dirs=set(options["exclude_dirs"]),
                max_file_bytes=options["max_file_mb"] * 1024 * 1024,
                progress_callback=lambda p: update_progress(job_id, p)
            )
            report_path = Path(app.instance_path) / "reports" / f"codesentry_{job_id}.xlsx"
            report_path.parent.mkdir(parents=True, exist_ok=True)
            build_workbook(result, report_path)
            with JOBS_LOCK:
                JOBS[job_id].update({
                    "status": "completed",
                    "progress": 100,
                    "result": result,
                    "report_path": str(report_path),
                    "completed_at": datetime.now(timezone.utc).isoformat()
                })
        except Exception as exc:
            with JOBS_LOCK:
                JOBS[job_id].update({"status": "failed", "error": str(exc)[:500]})

    def update_progress(job_id, progress):
        with JOBS_LOCK:
            if job_id in JOBS:
                JOBS[job_id]["progress"] = progress.get("percent", 0)
                JOBS[job_id]["progress_detail"] = progress

    @app.post("/api/scan")
    def start_scan():
        payload = request.get_json(silent=True) or {}
        raw_path = str(payload.get("project_path", "")).strip()
        if not raw_path:
            return jsonify({"error": "Project path is required."}), 400

        project = Path(os.path.expandvars(os.path.expanduser(raw_path))).resolve()
        if not project.exists() or not project.is_dir():
            return jsonify({"error": "The supplied path is not an existing directory."}), 400

        max_file_mb = payload.get("max_file_mb", 10)
        try:
            max_file_mb = int(max_file_mb)
        except (TypeError, ValueError):
            return jsonify({"error": "max_file_mb must be an integer."}), 400
        if not 1 <= max_file_mb <= 100:
            return jsonify({"error": "max_file_mb must be between 1 and 100."}), 400

        excludes = payload.get("exclude_dirs", list(DEFAULT_EXCLUDES))
        if not isinstance(excludes, list) or any(not isinstance(x, str) for x in excludes):
            return jsonify({"error": "exclude_dirs must be a list of directory names."}), 400

        job_id = uuid4().hex
        with JOBS_LOCK:
            JOBS[job_id] = {
                "id": job_id, "status": "queued", "progress": 0,
                "project": str(project), "created_at": datetime.now(timezone.utc).isoformat()
            }
        options = {"max_file_mb": max_file_mb, "exclude_dirs": excludes}
        Thread(target=run_job, args=(job_id, str(project), options), daemon=True).start()
        return jsonify({"job_id": job_id, "status": "queued"}), 202

    @app.get("/api/status/<job_id>")
    def job_status(job_id):
        with JOBS_LOCK:
            job = JOBS.get(job_id)
            if not job:
                abort(404)
            public = {k: v for k, v in job.items() if k not in {"result", "report_path"}}
            if job.get("status") == "completed":
                result = job["result"]
                public["summary"] = result["summary"]
                public["findings"] = result["findings"][:5000]
                public["files"] = result["file_summary"][:5000]
                public["packages"] = result["package_summary"][:2000]
                public["truncated_for_ui"] = len(result["findings"]) > 5000
            return jsonify(public)

    @app.get("/api/report/<job_id>")
    def download_report(job_id):
        with JOBS_LOCK:
            job = JOBS.get(job_id)
            if not job or job.get("status") != "completed":
                abort(404)
            report_path = job["report_path"]
        return send_file(report_path, as_attachment=True, download_name=f"CodeSentry_{job_id[:8]}.xlsx")

    return app
