from app.scanner import extract_comments, _findings_for_comment
from pathlib import Path

def test_python_comment_extraction():
    comments = extract_comments('x = 1\n# password = "hunter2"\n', Path("sample.py"))
    assert comments
    assert any("password" in text for _, text in comments)

def test_js_comment_extraction_does_not_flag_string():
    comments = extract_comments('const url = "https://example.com";\n// api_key = "abcdefgh123456"\n', Path("sample.js"))
    joined = "\n".join(text for _, text in comments)
    assert "api_key" in joined
    assert "https://example.com" not in joined

def test_secret_finding_is_masked():
    hits = _findings_for_comment('# password = "hunter2"', Path("x.py"), "x.py", "(root)", 1)
    assert hits
    assert "hunter2" not in hits[0]["evidence"]
